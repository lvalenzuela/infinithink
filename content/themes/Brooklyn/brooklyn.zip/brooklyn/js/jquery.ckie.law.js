/* <![CDATA[ */
;(function($){
	
	"use strict";
	
    $(document).ready(function(){
        
        /* check if cookie notification should be displayed or not */
        
        
        $('.ut-accept-cookie').click(function(event) {
            
            
            
            
            event.preventDefault();
            
        });
        
        $('.ut-decline-cookie').click(function(event) {
            
            
            
            
            event.preventDefault();
            
        });
    
    });
	
})(jQuery);
 /* ]]> */