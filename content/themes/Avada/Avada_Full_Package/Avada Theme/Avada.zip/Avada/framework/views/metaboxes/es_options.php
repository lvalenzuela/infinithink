<?php
$this->text(	'caption_1',
				__('Title', 'Avada'),
				''
			);
?>
<?php
$this->text(	'caption_2',
				__('Caption', 'Avada'),
				''
			);
?>
<div class="clear"></div>